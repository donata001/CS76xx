this program is written in python

users only need to install numpy as additional lib after intalling python 2.7

pip install numpy

sample command:

python finalproject.py input.txt